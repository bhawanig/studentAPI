const express = require('express');
const router = express.Router();
const userauth = require('../middleware/userauth');
const user = require('../controllers/usercontroller')
router.post('/createStudent', [userauth.verifyToken], user.createStudent)
router.post('/createCourse', [userauth.verifyToken], user.createCourse)
router.get('/student', [userauth.verifyToken], user.getStudent)
router.get('/course', [userauth.verifyToken], user.getCourse)
router.delete('/deleteAllStudent', [userauth.verifyToken], user.deleteStudent)
router.post('/login', user.login)
module.exports = router;