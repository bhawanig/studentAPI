const jwt = require("jsonwebtoken");
const config = {
    secret: "test-secret-key"
}
module.exports = {
    verifyToken : (req, res, next) => {
    let bearerHeader = req.headers.authorization;

    if (typeof bearerHeader == undefined) {
            return res.status(403).send({ message: "No token provided!" });
    }
    try {
            const bearerToken = bearerHeader.split(" ")[1];
            var token = bearerToken;
            jwt.verify(token, config.secret, (err, decoded) => {
                if (err) {
                return res.status(401).send({ message: "Unauthorized!" });
                }
                req.userId = decoded.id;
                next();
            });
        } catch (e) {
            // otherwise, return a bad request error
            return res.status(400).end()
        }
    }
}