const user = require('../models/user');
const course = require('../models/course');
const jwt = require('jsonwebtoken');
var bcrypt = require("bcryptjs");
const config = {
    secret: "test-secret-key"
}
module.exports = {
    createStudent: async (req, res) => {
        try {
            const data = {
                student_name: req.body.student_name,
                course_id: req.body.course_id,
                email: req.body.email,
                password: bcrypt.hashSync(req.body.password, 8)
            }
            user.create(data,  (err, student) => {
                if(student) {
                    res.status(200).json({message: "Student added successfully", student: student }); 
                } else {
                    res.status(400).json({message: err.message });
                }
            })
        } catch (err) {
            res.status(400).json({message: err.message });
        }
    },
    createCourse: async (req, res) => {
        try {
            const data = {
                course_name: req.body.course_name,
                course_score: req.body.course_score
            }
            await course.create(data,  (err, courses) => {
                if(courses) {
                    res.status(200).json({message: "Course added successfully", courses: courses }); 
                } else {
                    res.status(400).json({message: err.message });
                }
            })
        } catch (err) {
            res.status(400).json({message: err.message });
        }
    },
    getStudent: async (req, res) => {
        try {
            const students = user.findOne({ student_name: 'bhawani 44s' }).populate({ path: 'course_id' }).exec(function(err,studentList){
                if(studentList) {
                    res.status(200).json({message: "Student list found successfully", student: studentList });
                } else {
                    res.status(400).json({message: err.message });
                } 
            })
        } catch (err) {
            res.status(400).json({message: err.message });
        }
    },
    getCourse: async (req, res) => {
        try {
            course.find((err, courseList) => {
                if(course) {
                    res.status(200).json({message: "Course list found successfully", courses: courseList }); 
                } else {
                    res.status(400).json({message: err });
                }
            })
        } catch (err) {
            res.status(400).json({message: err.message });
        }
    },
    login: async (req, res) => {
        try {
            const data = {
                email: req.body.email,
                password: req.body.password
            }
            user.findOne({email: data.email},  async (err, user) => {
                if(user) {
                    var passwordIsValid = await bcrypt.compare(data.password, user.password);
                    if(!passwordIsValid) {
                        res.status(400).json({message: "Invalid password." });
                    } else {
                        var token = jwt.sign({ id: user.id, email: user.email }, config.secret, {
                            expiresIn: 86400 // 24 hours
                        });
                        delete user.password;
                        res.status(200).json({
                            message: "User login successfully.",
                            user: user,
                            accessToken: token
                        });
                    }
                } else {
                    res.status(400).json({message: "User not found." });
                }
            })
        } catch (err) {
            res.status(400).json({message: err.message });
        }
    },
    deleteStudent: (req, res) => {
        user.deleteMany({})
          .then(data => {
            res.send({
              message: `${data.deletedCount} User were deleted successfully!`
            });
          })
          .catch(err => {
            res.status(500).send({
              message:
                err.message || "Some error occurred while removing all User."
            });
          });
    }
}