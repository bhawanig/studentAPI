const mongoose = require("mongoose");
const userDataSchema = new mongoose.Schema({
    student_name: String,
    course_id: [{type: mongoose.Schema.Types.ObjectId, ref:'Course'}],
    email: { type: String, required: true, email: true, unique: true},
    password: { type: String, required: true}
})
const userData = mongoose.model('User', userDataSchema);
module.exports = userData;