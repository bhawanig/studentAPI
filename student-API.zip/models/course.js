const mongoose = require("mongoose");
const courseDataSchema = new mongoose.Schema({
    course_name:  String,
    course_score: Number,
    student: [{type: mongoose.Schema.Types.ObjectId, ref:'Student'}]
})
const courseData = mongoose.model('Course', courseDataSchema);
module.exports = courseData;